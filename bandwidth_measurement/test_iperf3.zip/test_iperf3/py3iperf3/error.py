"""
Runtime exception definition
"""

class IPerf3Exception(Exception):
    """Class for runtime program errors"""
    pass